Web App files available at 

https://drive.google.com/drive/folders/1nwhp-2Ecehw5p3wqS9i3sjwwySbykYDY?usp=sharing